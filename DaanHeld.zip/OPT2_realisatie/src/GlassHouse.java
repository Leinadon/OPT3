import java.lang.String;
import java.util.ArrayList;

public class GlassHouse {
    private int glassHouseId;
    private int paths;
    private String product;
    private static int lastNumber = 0;
    private ArrayList<Person> Working = new ArrayList<Person>();
    private ArrayList<Path> Paths = new ArrayList<Path>();

    public GlassHouse(String product)
    {
        this.glassHouseId = lastNumber++;
        this.product = product;
    }

    public ArrayList<Person> getWorking() {
        return Working;
    }

    public void addWorker(Person person) {
        Working.add(person);
    }

    public ArrayList<Path> getHasPaths() {
        return Paths;
    }

    public int getGlassHouseId() {
        return glassHouseId;
    }

    public int getPaths() {
        return paths;
    }

    public void setPaths(int paths) {
        this.paths = paths;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public Person GetPersonFromList( int input){
        for (int i = 0; i < Working.size(); i++) {
            if(Working.get(i).getId() == input) {
                return Working.get(i);
            }
        }
        return null;
    }
}
