import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Calculator {

    public double Average(String jobChoiseMade, double seconds, double amountOfPlants) {
        double speed = amountOfPlants/(seconds/60);
        System.out.printf("Je heb %.0f planten per minuut gedaan met %s\n",speed ,jobChoiseMade);
        return speed;
    }

    public int Stopwatch() throws InterruptedException, IOException {
        System.out.println("Druk op ENTER als je klaar bent met het pad:\n");
        boolean blankLine = true;
        int i = 0;
        loop:
        while (true){
            int available;
            while((available = System.in.available()) == 0) {
                TimeUnit.SECONDS.sleep(1);
                i++;
            }
            do {
                switch (System.in.read()) {
                    default:
                        blankLine = false;
                        break;
                    case '\n':
                        if (blankLine)
                            break loop;
                        blankLine = true;
                        break;
                }
            } while (--available > 0);
        }
        return i;
    }
}


