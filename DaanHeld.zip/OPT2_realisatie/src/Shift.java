public class Shift {
    private int id;
    private int length; //In hours
    private int startHour;
    private Person person;

    private static int lastNumber = 0;

    public Shift(int length,int startHour, Person person) {
        this.id = lastNumber++;
        this.length = length;
        this.startHour = startHour;
        this.person = person;
    }

    public boolean hasBreak() {
        if(person.getAge() < 18 && length >= 4) {
            return true;
        } else if (startHour <= 7) {
            return true;
        } else {
            return false;
        }
    }

    public int calculateBreak() {
        if(length < 4 ){
            return 0;
        } else if (length < 8){
            return 15;
        } else {
            return 30;
        }
    }

    public int getId() {
        return id;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}
