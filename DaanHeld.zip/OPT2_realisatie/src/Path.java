

public class Path {
    private int amountOfPlants;


    public Path(int amountOfPlants) {
        this.amountOfPlants = amountOfPlants;
    }

    public int getAmountOfPlants() {
        return amountOfPlants;
    }

    public void setAmountOfPlants(int amountOfPlants) {
        this.amountOfPlants = amountOfPlants;
    }

    @Override
    public String toString(){
        return "Aantal planten per pad: " + amountOfPlants;
    }
}


