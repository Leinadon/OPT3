public class Manager extends Person {
    private boolean admin;
    private String emailadres;

    public Manager(String firstName,
                   String lastName,
                   String emailadres,
                   int age,
                   double salary,
                   String phone,
                   double speed,
                   GlassHouse glassHouse) {
        super(firstName, lastName, emailadres, age, salary, phone, speed, glassHouse);
    }

    public boolean isAdmin() {
        return admin;
    }

    public void addPerson(Person person){
        GlassHouse glassHouse = super.getGlassHouse();
        glassHouse.addWorker(person);
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public String getEmailAdres() {
        return emailadres;
    }

    public void setEmailAdres(String emailadres) {
        this.emailadres = emailadres;
    }

}