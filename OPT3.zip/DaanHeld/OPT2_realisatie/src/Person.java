import java.util.ArrayList;

public class Person {
    private final int id;
    private String firstName;
    private String lastName;
    private String emailadres;
    private int age;
    private ArrayList<String> job = new ArrayList<String>();
    private double salary;
    private String phone;
    private double speed;
    private static int lastNumber = 1000;

    private GlassHouse glassHouse;


    public Person(String firstName, String lastName, String emailadres, int age, double salary, String phone,
                  double speed, GlassHouse glassHouse){
        this.id = lastNumber++;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailadres = emailadres;
        this.salary = salary;
        this.phone = phone;
        this.speed = speed;
        this.glassHouse = glassHouse;
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmailadres() {
        return emailadres;
    }

    public void setEmailadres(String emailadres) {
        this.emailadres = emailadres;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age ) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public GlassHouse getGlassHouse() {
        return glassHouse;
    }

    public void setGlassHouse(GlassHouse glassHouse) {
        this.glassHouse = glassHouse;
    }

    public ArrayList<String> getJob() {
        return job;
    }

    public String getJobName(int i) {
        return job.get(i);
    }

    public void addJob(String job) {
        this.job.add(job);
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    @Override
    public String toString() {
        return "Name: " + firstName + " " + lastName + "\n" +
                "E-mail: " + emailadres + "\n" +
                "Phone number: " + phone + "\n" +
                "Salary: " + salary + "\n" +
                "Job: " + job + "\n" +
                "Speed: " + speed + "\n" +
                "Id: " + id + "\n";
    }
}
