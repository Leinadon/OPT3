import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws InterruptedException, IOException {
        GlassHouse ActiTor = new GlassHouse("Tomaien");
        Manager testManager = new Manager("Joeri", "De Hoog", "joeri@gmail.com", 20,
                20.0,"06-54321452", 0.0, ActiTor);
        Person testPerson = new Person("Daniël", "Goedknegt", "21137943@student.hhs.nl",
                18,10.0, "06-42221141", 0.0, ActiTor);
        Person testPerson2 = new Person("Pieter", "Van De Berg", "123456789@student.hhs.nl",
                18,9.0, "06-12345678", 0.0, ActiTor);
        ActiTor.addWorker(testManager);
        ActiTor.addWorker(testPerson);
        ActiTor.addWorker(testPerson2);
        testManager.addJob("Blad snijden");
        testManager.addJob("Manager");
        testPerson.addJob("Plukken");
        testPerson.addJob("Blad snijden");
        testPerson2.addJob("Blad snijden");
        ActiTor.setPaths(20);

        Scanner scanner = new Scanner(System.in);
        Calculator calculator = new Calculator();
        Path path = new Path(100);

        Person person = ActiTor.GetPersonFromList(0);
        while(true){
            System.out.println("Welkom!\nVoor uw persoonsnummer in:");
            try {
                int input = scanner.nextInt();
                person = ActiTor.GetPersonFromList(input);
                if (!(person.getFirstName().isEmpty())){
                    break;
                }
            } catch (Exception e) {
                System.out.println("Graag een geldig id geven!\n");
            }
        }
        System.out.printf("Welkom %s %s\n", person.getFirstName(), person.getLastName());
        if (person.getJob().contains("Manager")) {
            while (true) {
                try {
                    System.out.println("Wat wil je doen:\n1) Persoon toevoegen\n2) Snelheid opvragen \n3) Salaris opvragen \n4) Zelf werken \n5) Programma afsluiten");
                    int input = scanner.nextInt();
                    if (input < 6 && input > 0) {
                        if (input == 1) {
                            scanner.nextLine();
                            System.out.println("Geef de Voornaam: ");
                            String inputFirstName = scanner.nextLine();
                            System.out.println("Geef de Achternaam: ");
                            String inputLastName = scanner.nextLine();
                            System.out.println("Geef het e-mail Adres: ");
                            String inputEMail = scanner.nextLine();
                            System.out.println("Geef het telefoonnummer: ");
                            String inputPhoneNumber = scanner.nextLine();
                            System.out.println("Geef het salaris op (vb: 10,0): ");
                            double inputSalary = scanner.nextDouble();
                            Person newperson = new Person(inputFirstName, inputLastName, inputEMail, 18, inputSalary, inputPhoneNumber, 0.0, ActiTor);
                            System.out.println("Wat voor werk gaat hij/zij doen?");
                            scanner.nextLine();
                            String inputJob = scanner.nextLine();
                            newperson.addJob(inputJob);
                        } else if (input == 2) {
                            System.out.println("Geef de ID van de persoon waarvan je de snelheid wilt weten:");
                            int qustionSpeed = scanner.nextInt();
                            System.out.println("De snelheid = " + ActiTor.GetPersonFromList(qustionSpeed).getSpeed());
                        } else if (input == 3) {
                            System.out.println("Geef de ID van de persoon waarvan je het salaris wilt weten:");
                            int qustionSalary = scanner.nextInt();
                            System.out.println("Het salaris = " + ActiTor.GetPersonFromList(qustionSalary).getSalary() + " euro per uur");
                        } else if (input == 4) {
                            break;
                        } else if (input == 5) {
                            System.exit(0);
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Graag een goede invoer");
                    scanner.next();
                }
            }
        }
        String jobChoiseMade = jobChoise(person, scanner);
        int time = calculator.Stopwatch();
        System.out.println(time);
        double speed = calculator.Average(jobChoiseMade, time, path.getAmountOfPlants());
        person.setSpeed(speed);
        System.out.println(person);
    }

    private static String jobChoise(Person person, Scanner scanner){
        int input = 0;
        while (true){
            try {
                System.out.println("\nWat ga je vandaag doen?\n");
                for (int i = 1; i <= person.getJob().size(); i++) {
                    System.out.printf("%d) %s\n", i, person.getJobName(i - 1));
                }
                input = scanner.nextInt()-1;
                if (input < 0 || input > person.getJob().size()-1){
                    System.out.println("Graag een goed cijfer in voeren");

                } else {
                    break;
                }
            } catch (Exception e) {
                System.out.println("Graag een goede invoer\n");
                scanner.next();
            }
        }
        return person.getJobName(input);
    }
}

