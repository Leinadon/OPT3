import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class Unit_Test {


    GlassHouse ActiTor = new GlassHouse("komkommers");
    Calculator calculator = new Calculator();

    @Test
    @DisplayName("Testing calculation.")
    public void testAverage(){
        assertEquals(1, calculator.Average("Bladplukken", 6000.0, 100.0));
    }
    Person personTest = new Person("Bob", "de Graaf", "test@gmail.com",18, 5.0, "1235433465", 4.0, ActiTor);

    @Test
    @DisplayName("Testing person.")
    public void testPerson(){
        assertEquals("Bob", personTest.getFirstName());
    }


    @Test
    @DisplayName("Testing stopwatch")
    public void testStopwatch() throws IOException, InterruptedException {
        int time = calculator.Stopwatch();
        boolean value = false;
        if (0 < time && time < 100){
            value = true;
        }
        assertTrue(value);
    }


    @Test
    @DisplayName("Testing add person")
    public void testAddPerson() {
        //Arrange
        Manager manager = new Manager("test", "test", "managerTest@gmail.com", 20,1.0, "76586574", 3.0, ActiTor);
        Person personTest2 = new Person("Tim", "Pronk", "Test2@gmail.com", 18,2.0, "7564523", 20.0, ActiTor);

        //Act
        manager.addPerson(personTest2);

        //Assert
        assertEquals(1, ActiTor.getWorking().size());
    }

    @Test
    public void Modified_ConditionDecision_Coverage_Testing() {
        Person jongerDan18 = new Person("Tim", "Pronk", "Test2@gmail.com", 17, 2.0, "7564523", 20.0, ActiTor);
        Person ouderDan18 = new Person("Tim", "Pronk", "Test2@gmail.com", 19,2.0, "7564523", 20.0, ActiTor);
        Shift youngPerson_shortShift_earlyStart_withBreak = new Shift(3, 6,jongerDan18);
        Shift oldPerson_shortShift_earlyStart_withBreak = new Shift(3, 6, ouderDan18);
        Shift youngPerson_longShift_lateStart_withBreak = new Shift(5, 8, jongerDan18);
        Shift youngPerson_shortShift_lateStart_withoutBreak = new Shift(3,8, jongerDan18);

        Assert.assertTrue(youngPerson_shortShift_earlyStart_withBreak.hasBreak());
        Assert.assertTrue(oldPerson_shortShift_earlyStart_withBreak.hasBreak());
        Assert.assertTrue(youngPerson_longShift_lateStart_withBreak.hasBreak());
        Assert.assertFalse(youngPerson_shortShift_lateStart_withoutBreak.hasBreak());
    }

    @Test
    public void Equivalentie_en_Randwaarden_Testen() {
        Person person = new Person("Tim", "Pronk", "Test2@gmail.com", 17, 2.0, "7564523", 20.0, ActiTor);
        Shift Drie_uur = new Shift(3, 8 , person);
        Shift Vier_uur = new Shift(4, 8 , person);
        Shift Zeven_uur = new Shift(7, 8 , person);
        Shift Acht_uur = new Shift(8, 8 , person);
        Shift Negen_uur = new Shift(9, 8 , person);

        Assert.assertEquals(0, Drie_uur.calculateBreak());
        Assert.assertEquals(15, Vier_uur.calculateBreak());
        Assert.assertEquals(15, Zeven_uur.calculateBreak());
        Assert.assertEquals(30, Acht_uur.calculateBreak());
        Assert.assertEquals(30, Negen_uur.calculateBreak());
    }
}

